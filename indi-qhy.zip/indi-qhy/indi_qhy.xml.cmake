<?xml version="1.0" encoding="UTF-8"?>
<driversList>
<devGroup group="CCDs">
    <device label="QHY CCD" mdpd="true" manufacturer="QHY">
        <driver name="QHY CCD">indi_qhy_ccd</driver>
        <version>@INDI_QHY_VERSION_MAJOR@.@INDI_QHY_VERSION_MINOR@</version>
    </device>
    <device label="Orion SSAG" mdpd="true" manufacturer="Orion">
        <driver name="QHY CCD">indi_qhy_ccd</driver>
        <version>@INDI_QHY_VERSION_MAJOR@.@INDI_QHY_VERSION_MINOR@</version>
    </device>
</devGroup>
<devGroup group="Focusers">
    <device label="QFocuser" manufacturer="QHY">
        <driver name="QFocuser">indi_qhy_focuser</driver>
        <version>@INDI_QHY_VERSION_MAJOR@.@INDI_QHY_VERSION_MINOR@</version>
    </device>
</devGroup>
<devGroup group="Telescopes">
    <device label="QHY Mount" manufacturer="QHY">
        <driver name="QHY Mount">indi_qhy_mount</driver>
        <version>@INDI_QHY_VERSION_MAJOR@.@INDI_QHY_VERSION_MINOR@</version>
    </device>
</devGroup>
</driversList>
